#!/bin/bash
pdb=$1
grep "END" $pdb >> END
wc -l < END >> frames
while IFS= read -r lines
   do
      sed 's/XXX/'$lines'/g' rog.f90 >> raw_rog.f90
done < frames
grep -e ALA -e ARG -e ASH -e ASN -e ASP -e CYS -e CYX -e GLH -e GLU -e GLN -e GLY -e HID -e HIE -e HIS -e HIP -e ILE -e LEU -e LYS -e MET -e PHE -e PRO -e SER -e THR -e TRP -e TYR -e VAL -e END $pdb >> raw.pdb
awk '{print $3,$7,$8,$9}' raw.pdb >> old
mv old raw.pdb
wc -l < raw.pdb >> pdb-lines
while IFS= read -r pdblines
   do
      sed -i 's/YYY/'$pdblines'/g' raw_rog.f90
done < pdb-lines
gfortran raw_rog.f90 -o rog.x
./rog.x
mv results.dat results-$pdb.dat
mv distr-rog-last1000ns.dat distr-rog-last1000ns-$pdb.dat
rm raw.pdb pdb-lines END frames raw_rog.f90 rog.x
echo "Done"
